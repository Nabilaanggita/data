# Vegetables & Fruits Finder > 2024-06-24 5:09pm
https://universe.roboflow.com/ggsharshitha/vegetables-fruits-finder

Provided by a Roboflow user
License: Public Domain

